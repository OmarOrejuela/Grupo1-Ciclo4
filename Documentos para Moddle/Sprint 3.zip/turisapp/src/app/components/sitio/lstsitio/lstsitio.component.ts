import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lstsitio',
  templateUrl: './lstsitio.component.html',
  styleUrls: ['./lstsitio.component.scss']
})
export class LstsitioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
