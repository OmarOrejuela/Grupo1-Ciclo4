import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frmregion',
  templateUrl: './frmregion.component.html',
  styleUrls: ['./frmregion.component.scss']
})
export class FrmregionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
