import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lstdepartamento',
  templateUrl: './lstdepartamento.component.html',
  styleUrls: ['./lstdepartamento.component.scss']
})
export class LstdepartamentoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
