import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frmdepartamento',
  templateUrl: './frmdepartamento.component.html',
  styleUrls: ['./frmdepartamento.component.scss']
})
export class FrmdepartamentoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
