import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lstpais',
  templateUrl: './lstpais.component.html',
  styleUrls: ['./lstpais.component.scss']
})
export class LstpaisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
