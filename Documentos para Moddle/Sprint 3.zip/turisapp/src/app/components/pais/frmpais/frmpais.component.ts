import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frmpais',
  templateUrl: './frmpais.component.html',
  styleUrls: ['./frmpais.component.scss']
})
export class FrmpaisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
