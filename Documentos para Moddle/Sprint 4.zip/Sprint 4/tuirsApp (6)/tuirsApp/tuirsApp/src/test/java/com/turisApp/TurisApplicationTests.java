package com.turisApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurisApplicationTests {

	@Test
	void contextLoads() {
	}

}
