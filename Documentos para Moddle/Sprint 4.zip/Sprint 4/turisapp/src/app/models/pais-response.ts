export interface PaisResponse {
  id_pais: number;
  nombre_pais: string;
}
