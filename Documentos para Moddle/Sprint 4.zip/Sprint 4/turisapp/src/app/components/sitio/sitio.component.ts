import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sitio',
  templateUrl: './sitio.component.html',
  styleUrls: ['./sitio.component.scss']
})
export class SitioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
