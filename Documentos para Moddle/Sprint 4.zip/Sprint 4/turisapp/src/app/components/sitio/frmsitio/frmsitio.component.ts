import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frmsitio',
  templateUrl: './frmsitio.component.html',
  styleUrls: ['./frmsitio.component.scss']
})
export class FrmsitioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
