import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frmcomida',
  templateUrl: './frmcomida.component.html',
  styleUrls: ['./frmcomida.component.scss']
})
export class FrmcomidaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
