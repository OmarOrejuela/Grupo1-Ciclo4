import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lstcomida',
  templateUrl: './lstcomida.component.html',
  styleUrls: ['./lstcomida.component.scss']
})
export class LstcomidaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
