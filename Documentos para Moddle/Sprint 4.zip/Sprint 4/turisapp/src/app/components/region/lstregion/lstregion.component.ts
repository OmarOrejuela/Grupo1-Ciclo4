import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lstregion',
  templateUrl: './lstregion.component.html',
  styleUrls: ['./lstregion.component.scss']
})
export class LstregionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
